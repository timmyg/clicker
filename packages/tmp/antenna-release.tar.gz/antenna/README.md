###### run local server that validates a directv address at 127.0.0.1:8080

json-server --watch mock/db.json --port 8080
